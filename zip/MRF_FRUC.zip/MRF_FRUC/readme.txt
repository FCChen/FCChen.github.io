usage : MRF_FRUC [in_name] [f_width] [f_height] [start_frame] [max_f_num] [inter_mode]

[in_name]
	Input video raw data, must be YUV420 format
	Suggesting video resolution : 1920x1080 for the best performance

[f_width]
[f_height]
	Frame width & height of input video

[start_frame]
	The starting frame number

[max_f_num]
	Number of frames to be processed

[inter mode]
	0 =	24Hz -> 1:5 up-conversion -> 120Hz
	1 =	60Hz -> 1:2 up-conversion -> 120Hz
	2 =	60Hz -> skip half frames -> 30Hz -> 1:2 up-conversion -> 60Hz
		output PSNR comparing to skipped frames

Example : MRF_FRUC vintagecar_cut.yuv 1920 1080 1 30 0

=========================================================================================

For any question, please contact : squallinck@gmail.com, Fu-Chen Chen